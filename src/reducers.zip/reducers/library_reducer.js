import data from './library_list.json';

export default () => data;
